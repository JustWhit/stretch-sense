function h = hline(y,varargin)
%HLINE plot horizontal lines at one or more y-values
%   HLINE() plots a line at y=0. 
%
%   HLINE(Y,...) plots lines at y-values specfied by vector Y. Additional
%   arguments are passed to the line function.
%
%   H = HLINE(...) returns a vector of handles to the line. H(1)
%   corresponds with the line at Y(1), and so on.
%
%   Example: dotted black lines at y = 1,2,...,5
%      hline(1:5,'color','k','linestyle',':'); % dotted black line

if nargin == 0
    y = 0;
end

assert(isnumeric(y) && isvector(y),'y must be a vector');

% convert to row vector if necessary
y = y(:)';

domain = get(gca,'xlim');
nLines = numel(y);
h = line(repmat(domain',1,nLines),[y;y],varargin{:});

