function h = vline(x,varargin)
%VLINE plot vertical lines at one or more x-values
%   VLINE() plots a line at x=0. 
%
%   VLINE(X,...) plots lines at x-values specfied by vector X. Additional
%   arguments are passed to the line function.
%
%   H = VLINE(...) returns a vector of handles H to the line. H(1)
%   corresponds with the line at Y(1), and so on.
%
%   Example: dotted black lines at x = 1,2,...,5
%      vline(1:5,'color','k','linestyle',':'); % dotted black line

if nargin == 0
    x = 0;
end

assert(isnumeric(x) && isvector(x),'x must be a vector');

% convert to row vector if necessary
x = x(:)';

range = get(gca,'ylim');
nLines = numel(x);
h = line([x;x],repmat(range',1,nLines),varargin{:});

